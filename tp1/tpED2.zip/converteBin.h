#ifndef CONVERTE_BIN_H
#define CONVERTE_BIN_H

// Converte um arquivo texto para binário
bool textoParaBinario(char*);

// Converte o .txt do nome do arquivo para .bin
char * trocaExtensao(char*);

#endif